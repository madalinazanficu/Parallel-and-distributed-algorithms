#include "task4.h"


void print_topology_task4(int rank, int P, int **topology, int my_leader) {
    cout << rank << " -> ";

    if (rank != P1 && my_leader != P1) {
        for (int i = 0; i < leaders; i++) {
            if (i == P1) {
                continue;
            }
            cout << i << ":";
            int j = 0;
        
            while (j + 1 < P && topology[i][j + 1] != 0) {
                cout << topology[i][j] << ",";
                j++;
            }
            if (topology[i][j] != 0) {
                cout << topology[i][j] << " ";
            }
        }
        cout << endl;
    } else {
        int i = P1;
        int j = 0;
        cout << i << ":";
        while (j + 1 < P && topology[i][j + 1] != 0) {
            cout << topology[i][j] << ",";
            j++;
        }
        if (topology[i][j] != 0) {
            cout << topology[i][j] << " ";
        }
        cout << endl;
    }
}


int **get_topology_task4(int rank, int P, int my_leader, 
                        std::vector<int> cluster) {
    int **topology = get_topology_generic(rank, P, my_leader, cluster, 
                                        leaders_collab_r0, leaders_collab_r1,
                                        print_topology_task4);
    return topology;
}

/*
* Leaders collaboration: P0-> P3 -> P2
*/
void leaders_collab_r0(int rank, int **topology,
                        int P, int **recv_topology) {
    MPI_Status status;
    if (rank == P0) {
        int dst = P3;
        print_message(rank, dst);
        for (int i = 0; i < 4; i++) {
            MPI_Send(topology[i], P, MPI_INT, dst, 0, MPI_COMM_WORLD);
        }

    } else if (rank == P3) {
        int src = P0;
        for (int i = 0; i < 4; i++) {
            MPI_Recv(recv_topology[i], P, MPI_INT, src, 0, MPI_COMM_WORLD, &status);
            for (int j = 0; j < P; j++) {
                if (topology[i][j] == 0) {
                    topology[i][j] = recv_topology[i][j];
                }
            }
        }
        int dst = P2;
        print_message(rank, dst);
        for (int i = 0; i < 4; i++) {
            MPI_Send(topology[i], P, MPI_INT, dst, 0, MPI_COMM_WORLD);
        }

    } else if (rank == P2) {
        int src = P3;
        for (int i = 0; i < 4; i++) {
            MPI_Recv(recv_topology[i], P, MPI_INT, src, 0, MPI_COMM_WORLD, &status);
            for (int j = 0; j < P; j++) {
                if (topology[i][j] == 0) {
                    topology[i][j] = recv_topology[i][j];
                }
            }
        }
    }
}

/*
* Leaders collaboration: P2 -> P3 -> P0
*/
void leaders_collab_r1(int rank, int **topology,
                        int P, int **recv_topology) {
    MPI_Status status;
    if (rank == P2) {
        int dst = P3;
        print_message(rank, dst);
        for (int i = 0; i < 4; i++) {
            MPI_Send(topology[i], P, MPI_INT, dst, 0, MPI_COMM_WORLD);
        }
    } else if (rank == P3) {
        int src = P2;
        for (int i = 0; i < 4; i++) {
            MPI_Recv(recv_topology[i], P, MPI_INT, src, 0, MPI_COMM_WORLD, &status);
            for (int j = 0; j < P; j++) {
                if (topology[i][j] == 0) {
                    topology[i][j] = recv_topology[i][j];
                }
            }
        }

        int dst = P0;
        print_message(rank, dst);
        for (int i = 0; i < 4; i++) {
            MPI_Send(topology[i], P, MPI_INT, dst, 0, MPI_COMM_WORLD);
        }

    } else if (rank == P0) {
        int src = P3;
        for (int i = 0; i < 4; i++) {
            MPI_Recv(recv_topology[i], P, MPI_INT, src, 0, MPI_COMM_WORLD, &status);
            for (int j = 0; j < P; j++) {
                if (topology[i][j] == 0) {
                    topology[i][j] = recv_topology[i][j];
                }
            }
        }
    }
}

