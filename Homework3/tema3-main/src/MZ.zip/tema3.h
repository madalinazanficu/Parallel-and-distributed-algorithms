#ifndef __TEMA3__
#define __TEMA3__

#include <iostream>
#include <vector>
#include <fstream>
#include <stdlib.h>
#include "mpi.h"
#include "task1.h"
#include "task2.h"
#include "task3.h"
#include "task4.h"
#include "helper.h"

using namespace std;


#endif  // __TEMA3__
